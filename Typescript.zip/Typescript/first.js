function greeter(person) {
    return "Hello," + person;
}
var user = 'komal';
console.log(greeter(user));
