var Student = /** @class */ (function () {
    function Student(Fname, Mname, Lname) {
        this.Fname = Fname;
        this.Mname = Mname;
        this.Lname = Lname;
        this.fullname = Fname + "" + Mname + " " + Lname;
    }
    return Student;
}());
function display(p1) {
    return "Hello," + p1.Fname + " " + p1.Lname;
}
var u = new Student("Komal", "S.", "Valagadde");
console.log(display(u));
