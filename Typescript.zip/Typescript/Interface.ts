class Student
{
	fullname:string;
	constructor(public Fname:string,public 	Mname: string,public Lname:string){
		this.fullname= Fname+""+Mname+" "+Lname;

	}
}


interface Person
{
	
	Fname:string;
	Lname:string;
}
function display(p1:Person){
	return "Hello,"+p1.Fname+" "+p1.Lname;

}
let u=new Student("Komal","S.","Valagadde");
console.log(display(u));