var a1;
var i;
a1 = [2015, 2016, 2017, 2018];
a1 = ["abc", "def", "xyz", "pqr"];
for (i = 0; i < a1.length; i++) {
    console.log(a1[i]);
}
