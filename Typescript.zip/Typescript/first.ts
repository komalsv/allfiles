function greeter(person){
	return "Hello,"+person;
}
let user ='komal';
console.log(greeter(user));