
let years1: Array<number>=[2015,2016,2017,2018];
for(let i of years1){
	console.log(i);
}

console.log("*************");
let years2: Array<number>=[2015,2016,2017,2018];
for(let i in years2){
	console.log(years2[i]);
}

console.log("*************");
let years3: Array<number>=[2015,2016,2017,2018];
years3.forEach(function(y,i){
	console.log(y);
});