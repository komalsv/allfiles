interface Student
{
	rno:number;
	Fname:string;
	Lname:string;
}
function display(s1:Student){
	return "Hello,"+s1.Fname+" "+s1.Lname+" with roll no "+s1.rno;

}
let u={rno:1,Fname:"Shifa",Lname:"R"};
console.log(display(u));