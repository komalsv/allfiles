var years1 = [2015, 2016, 2017, 2018];
for (var _i = 0, years1_1 = years1; _i < years1_1.length; _i++) {
    var i = years1_1[_i];
    console.log(i);
}
console.log("*************");
var years2 = [2015, 2016, 2017, 2018];
for (var i in years2) {
    console.log(years2[i]);
}
console.log("*************");
var years3 = [2015, 2016, 2017, 2018];
years3.forEach(function (y, i) {
    console.log(y);
});
