function display(value) {
    if (typeof (value) == "number")
        console.log("The given no is number");
    else if (typeof (value) == "string")
        console.log("The given no is String");
}
display(1);
display("abc");
