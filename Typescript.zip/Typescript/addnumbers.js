function addnumbers(a, b) {
    return a + b;
}
var sum = addnumbers("javaTpoint", 11);
console.log("sum of two numbers is:" + sum);
var arr;
arr = [1, 2, 3, 'def'];
console.log("Array[0]:" + arr[0]);
console.log("Arrray[1]" + arr[1]);
console.log("Arrray[2]" + arr[2]);
console.log("Arrray[3]" + arr[3]);
var arr1;
arr1 = [1, 2, 3, 4, 5];
console.log("Array[0]:" + arr1[0]);
console.log("Arrray[1]" + arr1[1]);
console.log("Arrray[2]" + arr1[2]);
console.log("Arrray[3]" + arr1[3]);
console.log("Arrray[4]" + arr1[4]);
console.log("Arrray[5]" + arr1[5]);
