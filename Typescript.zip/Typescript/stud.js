function display(s1) {
    return "Hello," + s1.Fname + " " + s1.Lname + " with roll no " + s1.rno;
}
var u = { rno: 1, Fname: "Shifa", Lname: "R" };
console.log(display(u));
