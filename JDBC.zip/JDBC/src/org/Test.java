package org;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
//import com.mysql.cj.api.jdbc.Statement;

public class Test {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		String url="jdbc:mysql://localhost:3306/project?useSSL=false";
		String un="root";
		String pwd="1234";
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection(url,un,pwd);
		String query="select Roll_no,firstname from students";
		Statement st=con.createStatement();
		
		ResultSet rs=st.executeQuery(query);
		System.out.println("Roll_no Firstname");
		while(rs.next())
		{
			int rn =rs.getInt("Roll_no");
			String nm=rs.getString("firstname");
			System.out.print(rn);
			System.out.print("   ");
			System.out.print(nm);
			System.out.println();
		}
		con.close();
	}

}
