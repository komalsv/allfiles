package org;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class InsertExample {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		String url="jdbc:mysql://localhost:3306/project?useSSL=false";
		String un="root";
		String pwd="1234";
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection(url,un,pwd);
		
		String query="select max(Roll_no) from students";
		Statement st1=con.createStatement();
		
		ResultSet rs1=st1.executeQuery(query);
		rs1.next();
		int tempid;
		tempid=rs1.getInt(1);
		int rno=tempid+1;
		
		//int r=6765;
		String fn="kkkkk";
		String ln="lllll";
		int a=18;
		
		
		String insertSt="insert into students values("+rno+",'"+fn+"','"+ln+"',"+a+")";
		
		
		Statement st=con.createStatement();
	
		st.executeUpdate(insertSt);
		
		System.out.println("Record Inserted sucessfully");
		
		con.close();
	}

}
