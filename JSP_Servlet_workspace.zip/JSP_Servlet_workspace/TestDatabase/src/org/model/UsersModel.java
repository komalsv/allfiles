package org.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.io.PrintWriter;

import javax.sql.DataSource;

import org.entity.User;

public class UsersModel {
	public List<User> listUsers(DataSource dataSource){
		List<User> listUsers=new ArrayList<>();
		Connection connect=null;
		Statement stmt=null;
		ResultSet rs=null;
		
		try {
			connect=dataSource.getConnection();
			
			String query="Select * from users";
			stmt=connect.createStatement();
			rs=stmt.executeQuery(query);
			
			while(rs.next())
			{
				listUsers.add(new User(rs.getInt("users_id"),rs.getString("username"),rs.getString("email")));
				
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return listUsers;
	}
	
	public boolean addUsers(DataSource dataSource,User newuser){
		List<User> listUsers=new ArrayList<>();
		Connection connect=null;
		Statement stmt=null;
		ResultSet rs=null;
		
		try {
			connect=dataSource.getConnection();
			String username=newuser.getUsername();
			String email=newuser.getEmail();
			String query="insert into users (username,email) values (username,email)";
			stmt=connect.prepareStatement(query);
			((PreparedStatement) stmt).setString(2,"username");
			((PreparedStatement) stmt).setString(3,"email");
			stmt.execute(query);
			
			
		}catch(SQLException e) {
			e.printStackTrace();
			
		}
		return true;
	}
}
