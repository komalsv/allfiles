package org.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class submit1
 */
@WebServlet("/submit1")
public class submit1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public submit1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		out.print("Name:");
		response.getWriter().println(request.getParameter("name")+"<br/>");
		out.print("Gender:");
		response.getWriter().println(request.getParameter("gender")+"<br/>");
		
		out.print("Languages known:");
		String[] lan=request.getParameterValues("language");
		if(lan != null)
		{
			for(int i=0;i<lan.length;i++)
			{
				out.print("<br/>");
				out.print(lan[i]);
			}
		}
		else
		{
			out.print("None selected");
		}
		out.print("<br/>");
		out.print("Country:");
		response.getWriter().println(request.getParameter("country")+"<br/>");
		out.print("City:");
		response.getWriter().println(request.getParameter("city")+"<br/>");
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
