package org.servlet;

public class UserDefined {

	public String Demo()
{
		return "Text from demo method";
}
	
}
