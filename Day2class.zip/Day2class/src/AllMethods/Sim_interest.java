package AllMethods;

import java.util.Scanner;

public class Sim_interest {
	Scanner sc=new Scanner(System.in);
	
	public double simple_interest(int p,int r,int t)
	{
		
		
		double si=(p*t*r)/100;
		return si;
	}
	
}
