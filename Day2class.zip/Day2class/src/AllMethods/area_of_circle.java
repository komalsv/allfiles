package AllMethods;

import java.util.Scanner;

public class area_of_circle {
	Scanner sc=new Scanner(System.in);
	public double area(int r)
	{
		double a=0.0f;
		
		a=3.14*r*r;
		return a;
	}
	
}
