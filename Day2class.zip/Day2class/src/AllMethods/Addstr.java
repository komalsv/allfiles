package AllMethods;

public class Addstr {

	public int add(int a,int b)
	{
		int s=0;
		s=a+b;
		return s;
	}
	
	public String addstr(String s1,String s2)
	{
		String s;
		s=s1+s2;
		
		return s;
	}
}
