package inheritance;

public class Plant extends Living_thing{
public String type;
public Plant()
{
	System.out.println("This is Plant default constructor");
}

public Plant(String c,int l,String t)
{
	super(c,l);
	type=t;
	System.out.println("This is plant constructor");
}
	
}
