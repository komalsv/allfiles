package inheritance;

public class Rectangle extends Shape{
	
	public float l;
	public float b;
	
	public void display() {
		System.out.println("lenght of a rectangle:"+l);
		System.out.println("breadth of a rectangle:"+b);
		System.out.println("area"+area);
		
	}
	public double area()
	{
		double area=0;
		area=l*b;
		return area;
	}
}
