package inheritance;

public class Test {

	public static void main(String[] args) {
		Shape S=new Shape();
		Circle Cir=new Circle();
		Rectangle Rec=new Rectangle();
		Triangle Tri=new Triangle();
		Cir.color="Red";
		Cir.no_of_sides=0;
		Cir.radius=4;
		Cir.area=Cir.area();
		Rec.no_of_sides=4;
		Rec.b=5;
		Rec.l=7;
		Rec.area=Rec.area();
		Tri.no_of_sides=3;
		Tri.base=2.5f;
		Tri.height=5;
		Tri.area=Tri.area();
		
		S.display();
		Cir.display();
		Rec.display();
		Tri.display();
	}

}
