package inheritance;

public class Circle extends Shape{
	public int radius;
	
	
	public void display()
	{
		System.out.println("radius of a circle"+radius);
		System.out.println("area"+area);
	}
	public double area()
	{
		double area=0;
		area=3.142*(radius*radius);
		return area;
	}
	
}
