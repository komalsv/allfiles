package inheritance;

public class Shape {
		
		public String color;
		public int no_of_sides;
		public double area;
		
		public void display()
		{
			System.out.println("color="+color);
			System.out.println("Sides="+no_of_sides);
			System.out.println("area="+area);
		}

}
 