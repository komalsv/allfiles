package inheritance;

public class Triangle extends Shape{
	public float base;
	public float height;
	
	public void display() {
		System.out.println("base of a triangle:"+base);
		System.out.println("height of a rectangle:"+height);
		System.out.println("area"+area);
	}
	public double area()
	{
		double area=0;
		area=0.5*base*height;
		return area;
	}

}
