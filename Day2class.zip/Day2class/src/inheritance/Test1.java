package inheritance;

public class Test1 {

	public static void main(String[] args) {
		Living_thing l1=new Living_thing();
		Plant p1=new Plant();
		Rose r1=new Rose();
		Alovera a1=new Alovera();
		
		Living_thing l2=new Living_thing("Brown",20);
		Plant p2=new Plant("Green",10,"Flower");
		Rose r2=new Rose("Red",2,"Flower","rosy");
		Alovera a2=new Alovera("Green",5,"Herbal","Bitter");
		
		System.out.println(l2.colour);
		System.out.println(l2.lifespan);
		System.out.println(p2.colour);
		System.out.println(p2.lifespan);
		System.out.println(p2.type);
		System.out.println(r2.colour);
		System.out.println(r2.lifespan);
		System.out.println(r2.type);
		System.out.println(r2.fragrance);
		System.out.println(a2.colour);
		System.out.println(a2.lifespan);
		System.out.println(a2.type);
		System.out.println(a2.taste);
		
	}

}
