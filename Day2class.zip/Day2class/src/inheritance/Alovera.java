package inheritance;

public class Alovera extends Plant{
	public String taste;
	
	public Alovera()
	{
		System.out.println("This is Alovera default constructor");
	}
	public Alovera(String c,int l,String t,String ta)
	{
		super(c,l,t);
		taste=ta;
		System.out.println("This is Alovera constructor");
	}
}
