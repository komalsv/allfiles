package inheritance;

public class Living_thing {
	public String colour;
	public int lifespan;
	public Living_thing()
	{
		System.out.println("This is Living_thing default constructor");
	}
	
	public Living_thing(String c,int l)
	{
		colour=c;
		lifespan=l;
		System.out.println("This is Living_thing constructor");
	}
}
