package inheritance;

public class Rose extends Plant{
	public String fragrance;
	public Rose()
	{
		System.out.println("This is Rose default constructor");
	}
	public Rose(String c,int l,String t,String f)
	{
		super(c,l,t);
		fragrance=f;
		System.out.println("This is Rose constructor");
	}
}
