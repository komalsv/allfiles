package Test;

import AllMethods.Sim_interest;
import AllMethods.area_of_circle;

public class Test {
	public static void main(String[] args)
	{
		
		
		
		area_of_circle c1=new area_of_circle();
		double a=c1.area(4);
		System.out.println("area of circle="+a);
	}
}
