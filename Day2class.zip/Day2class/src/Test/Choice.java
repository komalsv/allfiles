package Test;

import java.util.Scanner;

import AllMethods.Addstr;
import AllMethods.Sim_interest;
import AllMethods.area_of_circle;

public class Choice {
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		Addstr a1=new Addstr();
		Sim_interest si1=new Sim_interest();
		area_of_circle ac1=new area_of_circle();
		System.out.println("enter the choice:");
		System.out.println("1: add two numbers");
		System.out.println("2: add two strings and print hello with name");
		System.out.println("3: simple interest");
		System.out.println("4:Area of circle");
		int ch=sc.nextInt();
		switch(ch)
		{
		case 1:System.out.println("enter the first number:");
				int a=sc.nextInt();
				System.out.println("enter the second number:");
				int b=sc.nextInt();
				System.out.println(a1.add(a,b));
				break;
		case 3:System.out.println("enter the principal:");
			int p=sc.nextInt();
			System.out.println("enter the rate of intrest:");
			int r=sc.nextInt();
			System.out.println("enter the time:");
			int t=sc.nextInt();
			
			System.out.println("simple intrest="+si1.simple_interest(p,r,t));
			break;
		case 2:System.out.println("enter the string1:");
			   String s1=sc.next();
			   System.out.println("enter the string2:");
			   String s2=sc.next();
			   System.out.println(a1.addstr(s1,s2));
			   System.out.println("Hello "+s1+" "+s2);
			   break;
		case 4:System.out.println("enter the radius of the circle:");
					int radius=sc.nextInt();
					System.out.println("area of circle is="+ac1.area(radius));
					break;
		default:System.out.println("enter the right chioce");			
		}
	}
}
