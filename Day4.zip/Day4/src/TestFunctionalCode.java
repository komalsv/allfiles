import java.util.function.*;


public class TestFunctionalCode {

		public static String method1(String n){
			return "Hello"+n;
		}
		public static void printValue(int v)
		{
			System.out.println(v);
		}
		
	public static void main(String[] args) {
		Predicate<Integer> pr=a->(a>18);
		System.out.println(pr.test(10));
		
		Function<String,String> fun= TestFunctionalCode::method1;
		System.out.println(fun.apply("komal"));
		
		Consumer<String> c1=TestFunctionalCode::method1;
		c1.accept("Sneha");
		Consumer<Integer> c2=TestFunctionalCode::printValue;
		c2.accept(10);
		
		
			BiFunction<String,String,String> bi=(x,y)->{return x+y;};
			System.out.println(bi.apply("welcome","class"));
	}

}
