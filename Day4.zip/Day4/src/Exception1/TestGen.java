package Exception1;

public class TestGen {

	public static void main(String[] args) {

		Gen G = new Gen();
		G.method1();
		
			try
			{
				G.method2();
			}
			catch(Exception e)
			{
				System.out.println("divide by zero and exception handeled by method2");
			}
		
		G.method3();
		try {
			G.checkAge(15);
		}
		catch ( InvalidAgeException e)
		{
			System.out.println(e);
		}
		

	}

}
