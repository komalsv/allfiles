package Exception1;

public class Gen {

	public void method1() {
		try {
			int x=10/0;
		} catch(Exception e) {
			System.out.println("divide by zero and exception handeled by method1");
		}
	}
	
	//declaring  the exception
	public void method2() throws Exception
	{
	int x=10/0;
	}
	public void checkAge(int age) throws InvalidAgeException
	{
		if(age<18)
			throw new InvalidAgeException("You are not an adult");
			else
				System.out.println("You are an adult and can vote");
	}
	public void method3() 
	{
		try {
	int[] a=new int[3];
	a[0]=10;
	a[1]=20;
	a[2]=30;
	//a[3]=40;
	}
		catch(ArithmeticException e)
		{
			System.out.println("Divide by zero");
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Array referring to out of bounds index");
		}
		finally
		{
			System.out.println("finally close all the resources");
		}
		
	}
}
