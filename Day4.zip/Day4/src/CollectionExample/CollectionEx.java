package CollectionExample;

import java.util.HashSet;
import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.Queue;

public class CollectionEx {
	public void HashEx()
	{
		HashSet<String> hset=new HashSet<String>();
		hset.add("Tomato");
		hset.add("Carrot");
		hset.add("Radish");
		hset.add("Potato");
		hset.add(null);
		hset.add("Tomato");
		hset.add("Carrot");
		
		System.out.println(hset);
	}
	public void QueueEx()
	{
		Queue<String> q=new PriorityQueue<String>();
		q.add("steve");
		q.add("nayana");
		q.add("komal");
		q.add("shifa");
		q.add("raj");
		//q.add("nayana");
		//q.add(null);
		
		Iterator<String> itr=q.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		/*System.out.println("head:"+q.element());
		System.out.println("head:"+q.peek());
		System.out.println("Iterating the queue element:");
		
		q.remove();
		q.poll();
		System.out.println("after removing two elements:");
		Iterator<String> itr2=q.iterator();
		while(itr2.hasNext())
		{
			System.out.println(itr2.next());
		}
		*/
	}
}
