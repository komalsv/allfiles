package CollectionExample;

public class testColl {

	public static void main(String[] args) {
		CollectionEx c=new CollectionEx();
		c.HashEx();
		c.QueueEx();
		
	}

}
