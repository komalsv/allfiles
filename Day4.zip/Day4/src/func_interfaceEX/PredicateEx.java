package func_interfaceEX;
import java.util.function.*;

public class PredicateEx {

	public static void main(String[] args) {
		           

	}

}
