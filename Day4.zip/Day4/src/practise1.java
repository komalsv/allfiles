import java.util.function.Predicate;

public class practise1 {

	/*public static Boolean method1(int x)
	{
		int y=20;
		int z=30;
		if(x>y && x>z)
		{
			System.out.println("x is greater");
			return(True);
		}
		else if(y>x && y>z)
		{
			System.out.println("y is greater");
			return(True);
		}
		else if(z>x && z>y )
		{
			System.out.println("z is greater");
			return(True);
		}
		else
			return(False);
	} */
	
	public static void main(String[] args) {
		
		//int y=20,z=30;
		Predicate<Integer> p=practise1::method1;
		System.out.println(p.test(10));
	}

}
