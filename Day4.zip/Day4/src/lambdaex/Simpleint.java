package lambdaex;

public class Simpleint {
	public static void main(String[] args)
	{
		Calculable c=(p,t,r)->((p*t*r)/100);
			
		
		System.out.println("simple interest is:"+c.calculate(1000,3,2));
	}
}
