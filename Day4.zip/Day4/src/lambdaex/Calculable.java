package lambdaex;

public interface Calculable {
	public int calculate(int p,int t,int r);
}
