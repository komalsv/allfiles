package day5;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;

public class outputfileEX {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
			/*FileOutputStream fout=new FileOutputStream("D:\\KomalWorkspace\\Day4\\src\\day5\\abc.txt");
			String s="Welcome to my class,this java 2nd batch";
			byte b[]=s.getBytes(); //converting string to byte
			fout.write(b);
			fout.close();*/
			FileWriter fw=new FileWriter("D:\\KomalWorkspace\\Day4\\src\\day5\\abc.txt");
			fw.write("welcome to slk");
			fw.getClass();
			
			FileReader fin=new FileReader("D:\\KomalWorkspace\\Day4\\src\\day5\\abc.txt");
			int i;
			while((i=fin.read())!=-1)
			{
				System.out.print((char)i);
			}
			System.out.println();
			fin.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		System.out.println("Success");
	}

}
