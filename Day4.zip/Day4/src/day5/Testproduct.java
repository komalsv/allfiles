package day5;

import java.util.List;
import java.util.stream.Collectors;
import java.util.*;

public class Testproduct {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Product> ls=new ArrayList<Product>();
		ls.add(new Product("Lakme",1,30000f));
		ls.add(new Product("SMASHBOX",2,30000f));
		Product p1=new Product("MAC",4,70000f);
		Product p2=new Product("MAYBELLINE",5,50000f);
		Product p3=new Product("LA GIRL",3,40000f);
		ls.add(p1);
		ls.add(p2);
		ls.add(p3);
		for(Product p:ls)
		{
			System.out.println("name-"+p.getName()+"\n Product id-"+p.getId()+"\n Price-"+p.getPrice()+"\n");
		}
		System.out.println();
		
		List<Float> pl=new ArrayList<Float>();
		for(Product p11:ls)
		{
			if(p11.price>30000)
				pl.add(p11.price);
		}
	
	System.out.println(pl);
	
	List<String> n=new ArrayList<String>();
	for(Product p12:ls)
	{
		if(p12.price>30000) {
		n.add(p12.name);
		}
		//n.add(p12.price);
	}
	System.out.println(n);
	System.out.println("using stream:");
	/*with stream*/
	List<String> km=ls.stream().filter(m->m.price>30000).map(m->m.name)
			.collect(Collectors.toList());
	System.out.println(km);
	
	ls.stream().filter(p->p.price==30000)
	.forEach(p->System.out.println(p.name));
	
	
	double totalprice=ls.stream()
			.collect(Collectors.summingDouble(p->p.price));
	
	System.out.println(totalprice);
	//min() to  get min element
	Product pb=ls.stream().min((pp1,pp2)->pp1.price<pp2.price?1:-1).get();
	System.out.println(pb.price);
	
	Product pa=ls.stream().max((pp1,pp2)->pp1.price>pp2.price?1:-1).get();
	System.out.println("Maximum="+pa.price);
	
	//count() will count the elements for which condition is satisfied
	long count=ls.stream()
			.filter(p->p.price<=30000)
			.count();
	System.out.println(count);
	
	//create set
	Set<Float> km1=ls.stream()
			.filter(m1->m1.price<40000)
			.map(m1->m1.price)
			.collect(Collectors.toSet());
	System.out.println(km1);
	
	//Converting list into a map
	Map<Integer,String> ppmap=ls.stream()
			.collect(Collectors.toMap(p->p.id,p->p.name));
	System.out.println(ppmap);
	
	//using method reference in stream
	List<Float> km2=ls.stream().map(Product::getPrice)
			.collect(Collectors.toList());
	System.out.println(km2);
	
	}
	
	

}
