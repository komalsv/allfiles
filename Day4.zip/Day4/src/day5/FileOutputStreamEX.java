package day5;

import java.io.FileInputStream;
import java.io.FileOutputStream;

public class FileOutputStreamEX {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
			FileInputStream fin=new FileInputStream("D:\\KomalWorkspace\\Day4\\src\\day5\\abc.txt");
			int i=0;
			while((i=fin.read())!=-1)
			{
				System.out.print((char)i);
			}
			System.out.println();
			fin.close();
			System.out.println("success");
		}catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
