package day5;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class ObjoutEX {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Student s1=new Student(12,"komal");
		FileOutputStream fout=new FileOutputStream("D:\\KomalWorkspace\\Day4\\src\\day5\\abc.txt");
		ObjectOutputStream out=new ObjectOutputStream(fout);
		out.writeObject(s1);
		out.flush();
		out.close();
		System.out.println("success");}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
