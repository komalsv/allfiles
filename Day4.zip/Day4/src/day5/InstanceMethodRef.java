package day5;

public class InstanceMethodRef {
	public void saysomething()
	{
		System.out.println("Hello,this is non-static method");
	}
	public static void main(String[] args) {
		InstanceMethodRef mref=new InstanceMethodRef();
		mref.saysomething();
		Sayable s=mref::saysomething;
		s.say();
		
		Sayable s1=new InstanceMethodRef()::saysomething;
		s1.say();

	}

}
