package day5;

public interface Sayable {
	public void say();
}
