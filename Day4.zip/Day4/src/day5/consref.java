package day5;

interface Messageable
{
			Message getMessage(String msg,int n);
}

class Message
{
	public Message(String msg,int n)
	{
	System.out.println(msg);
	System.out.println(n);
	}
}

public class consref {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Message m2=new Message("hello",6);
		Messageable ms1=Message::new;
		
		Messageable m1=Message::new;
		m1.getMessage("hii",5);
	}

}
