package day5;

import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class objinputEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			//Student s1=new Student(12,"komal");
		FileInputStream fin=new FileInputStream("D:\\KomalWorkspace\\Day4\\src\\day5\\abc.txt");
		ObjectInputStream in=new ObjectInputStream(fin);
		Student s=(Student)in.readObject();
		System.out.println("id="+s.id+" name="+s.name);
		//in.flush();
		in.close();
		System.out.println("success");}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
