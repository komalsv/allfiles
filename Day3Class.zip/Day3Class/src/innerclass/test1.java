package innerclass;

public class test1 {

	public static void main(String[] args) {
		Cpu C=new Cpu();
		C.processes();

	}

}
