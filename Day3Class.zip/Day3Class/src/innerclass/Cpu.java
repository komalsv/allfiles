package innerclass;

public class Cpu {
	
	protected class Motherboard
	{
		public void display()
		{
			System.out.println("This is Motherboard");
		}
	}
	public void processes()
	{
		Motherboard M= new Motherboard();
		M.display();
		System.out.println("CPU is processing");
	}
}
