package inheritance;

public class Automobile {
		public String Color;
		public String Engine;
		
		public Automobile(String C, String E)
		{
			Color=C;
			Engine=E;
			System.out.println("This is automobile constructor");
		}
}
