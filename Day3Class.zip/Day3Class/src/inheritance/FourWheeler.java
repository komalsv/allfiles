package inheritance;

public abstract class FourWheeler extends Automobile {
		public int Wheels;
		
		public FourWheeler(String C,String E, int W)
		{
			super(C,E);
			Wheels= W;
			
			System.out.println("This is four wheeler constructor");
		}
		public abstract void starts();
		
}
