package inheritance;

public class Car extends FourWheeler {
		public String Brand;
		
		public Car(String C, String E, int W, String B)
		{
			super(C,E,W);
			Brand=B;
			
			System.out.println("This is car constructor");
		}
		public void starts()
		{
			System.out.println("Car starts by key or push");
		}
}
