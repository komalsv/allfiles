package test;

import inheritance.Automobile;
import inheritance.Car;
import inheritance.FourWheeler;

public class TestAutomobile {

	public static void main(String[] args) {
		Automobile Auto=new Automobile("RED","INTERNAL");
		System.out.println(Auto.Color);
		System.out.println(Auto.Engine);
		System.out.println();
		//FourWheeler Four=new FourWheeler("WHITE","PETROL",4);
		/*System.out.println(Four.Color);
		System.out.println(Four.Engine);
		System.out.println(Four.Wheels);*/
		System.out.println();
		Car Ca=new Car("SILVER","PETROL",4,"AUDI");
		System.out.println(Ca.Color);
		System.out.println(Ca.Engine);
		System.out.println(Ca.Brand);

		FourWheeler f1=new Car("white","petrol",4,"Audi");
		System.out.println(f1.Color);
		System.out.println(f1.Engine);
		System.out.println(f1.Wheels);
		f1.starts();
		//System.out.println(Ca.Brand);
	}

}
