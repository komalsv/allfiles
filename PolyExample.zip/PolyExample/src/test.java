import java.util.Scanner;

public class test {

	public static void main(String[] args) {
		Liquid water =new Liquid();
		Milk tonedmilk =new Milk();
		Coffee latte=new Coffee();
		CoffeeMug myMug=new CoffeeMug();
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter what u want to drink: 1-water,2-milk,3-coffee");
		int ch=sc.nextInt();
		
		switch(ch)
		{
		case 1:myMug.addLiquid(water);
		break;
		case 2:myMug.addLiquid(tonedmilk);
		break;
		case 3:myMug.addLiquid(latte);
		break;
		default:System.out.println("enter correct choice");
		break;
		}
	
		myMug.wash();
		
	}

}
