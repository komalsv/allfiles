
public class Coffee extends Liquid{
	public void swirl()
	{
		System.out.println("swirling coffee");
	}
}
