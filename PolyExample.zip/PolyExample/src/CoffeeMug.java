
public class CoffeeMug implements Washable{
	public void wash()
	{
		System.out.println("You are washing mug");
	}
	
	public void addLiquid(Liquid li)
	{
		
		//li.swirl();
		if(li instanceof Milk)
		{
			li.swirl();
			System.out.println("you got milk");
		}
		else if(li instanceof Coffee)
		{
			li.swirl();
			System.out.println("you got coffee");
		}
		else
		{
			li.swirl();
			System.out.println("you got water");
		}
			
		
	}
}
